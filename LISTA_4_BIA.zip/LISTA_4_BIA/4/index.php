<?php

    require_once "Funcionario.php";

    $funcionario1 = new Funcionario();
    $funcionario1->nome = "Carina  Pinheiro";
    $funcionario1->cargo = "Gestora de RH";
    $funcionario1->salario = 3570.20;

    echo "<p> " . $funcionario1->exibir() . " </p>";
            
?>