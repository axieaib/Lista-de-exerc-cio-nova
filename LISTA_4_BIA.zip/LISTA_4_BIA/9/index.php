<?php

    require_once "Agenda.php";

    $agenda1 = new Agenda();
    $agenda1->nomeContato = "Cami :P";
    $agenda1->telefone = "(12) 99999-9999";
    $agenda1->email = "camiilupus47@gmail.com";
    $agenda1->favorito = true;

    echo "<p> " . $agenda1->exibirContato() . " </p>";
            
?>